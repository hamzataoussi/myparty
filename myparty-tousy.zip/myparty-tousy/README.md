PlanMe - HAMZA ET TOUSY 
 19/06/2023

My final project is a web application that allows users to customize their own events,
as well as send invitations to other users registered on the website. Once you are registered
and logged in, you will have the ability to view your 'Invited' via nav bar in the top right corner
as well as being able to create and view your own events. The 'Create Party' button
will bring you to a form where you can fill out the event name, date, location, greeting,
necessities, and users to invite. Once you 'Create Party' it will update the database
and display all of the users created parties. You can easily view 'More...' or 'Delete'
these with their respective buttons. Then if you go into your Invited you will be able
to view all invited parties. As with the home page, you'll be able to view 'More...'
information about that event, as well as the ability to 'Decline' that invitation.

Hope you enjoy my Final Project
- hamza et tousy